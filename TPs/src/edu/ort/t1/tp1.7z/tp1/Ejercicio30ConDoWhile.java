package edu.ort.t1.tp1;

import java.util.Scanner;

public class Ejercicio30ConDoWhile {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int num1, num2;
		char operador;
		boolean finalizar = false;

		do {
			System.out.println("Ingrese la operacion a realizar (+ - * / ) o F para finalizar");
			operador = input.next().charAt(0);
			if (operador == '+' || operador == '-' || operador == '/' || operador == '*' || operador == 'f'
					|| operador == 'F') {
				if (operador == 'F' || operador == 'f') {
					finalizar = true;
				} else {
					System.out.println("Ingrese un numero entero");
					num1 = input.nextInt();
					System.out.println("Ingrese otro numero entero");
					num2 = input.nextInt();

					switch (operador) {
					case '+':
						System.out.println(num1 + num2);
						break;
					case '-':
						System.out.println(num1 - num2);
						break;
					case '*':
						System.out.println(num1 * num2);
						break;
					case '/':
						if (num2 != 0) {
							System.out.println((double)num1 / (double)num2);
						} else {
							System.out.println("Error, no se puede dividir por cero");
						}
						break;
					}
				}
			} else {
				System.out.println("Operador invalido");
			}
		} while (!finalizar);

		input.close();

	}
}
